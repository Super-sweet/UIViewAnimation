//
//  UIView+XCAnimation.m
//  XcodeAnimation
//
//  Created by xuchao on 16/8/2.
//  Copyright © 2016年 none. All rights reserved.
//

#import "UIView+XCAnimation.h"

@implementation UIView (XCAnimation)

//简单的缩放动画
-(CAAnimation *)setupScaleAnimation{

    CABasicAnimation * scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    scaleAnimation.duration = 3.0;
    scaleAnimation.fromValue = [NSNumber numberWithFloat:1.0];
    scaleAnimation.toValue =[NSNumber numberWithFloat:3.0];
    scaleAnimation.repeatCount = MAXFLOAT;
    scaleAnimation.autoreverses = YES;
    scaleAnimation.fillMode = kCAFillModeForwards;
    scaleAnimation.removedOnCompletion = NO;
    return scaleAnimation;

}
//简单的移动动画
-(CAAnimation *)setupMoveAnimation{

    CABasicAnimation * moveAnimation = [CABasicAnimation animationWithKeyPath:@"position"];
    moveAnimation.fromValue = [NSValue valueWithCGPoint:self.layer.position];
    moveAnimation.toValue = [NSValue valueWithCGPoint:CGPointMake(self.layer.position.x+50, self.layer.position.y+50)];
    moveAnimation.autoreverses = YES;
    moveAnimation.duration = 3.0;
    moveAnimation.removedOnCompletion = NO;
    moveAnimation.repeatCount = MAXFLOAT;
    return moveAnimation;
}
//简单的旋转动画
-(CAAnimation *)setupRotationAnimation{

    CABasicAnimation * rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.x"];
    rotationAnimation.duration = 3;
    rotationAnimation.autoreverses = YES;
    rotationAnimation.fromValue = [NSNumber numberWithFloat:0.0f];
    rotationAnimation.toValue = [NSNumber numberWithFloat:4 * M_PI];
    rotationAnimation.fillMode = kCAFillModeBoth;
    return rotationAnimation;
    
}
//组合动画
-(CAAnimation *)setupGroupAnimation{

    CAAnimationGroup * groupAninamtion = [CAAnimationGroup animation];
    groupAninamtion.duration = 3.0;
    groupAninamtion.animations = @[[self setupRotationAnimation],[self setupMoveAnimation]];
    groupAninamtion.autoreverses = YES;
    groupAninamtion.repeatCount = MAXFLOAT;
    return groupAninamtion;
    
}

@end
