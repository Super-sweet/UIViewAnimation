//
//  UIView+XCAnimation.h
//  XcodeAnimation
//
//  Created by xuchao on 16/8/2.
//  Copyright © 2016年 none. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (XCAnimation)

//简单的缩放动画
-(CAAnimation *)setupScaleAnimation;
//简单的一动动画
-(CAAnimation *)setupMoveAnimation;
//简单的旋转动画
-(CAAnimation *)setupRotationAnimation;
//组合动画
-(CAAnimation *)setupGroupAnimation;
@end
