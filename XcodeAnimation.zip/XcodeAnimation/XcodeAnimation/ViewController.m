//
//  ViewController.m
//  XcodeAnimation
//
//  Created by xuchao on 16/8/2.
//  Copyright © 2016年 none. All rights reserved.
//

#import "ViewController.h"
#import "UIView+XCAnimation.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *label;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
  
    [self.label.layer addAnimation:[self.view setupGroupAnimation] forKey:@"ss"];
}

//简单的缩放动画
//-(CAAnimation *)setupScaleAnimation{
//    
//    CABasicAnimation * scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
//    scaleAnimation.duration = 3.0;
//    scaleAnimation.fromValue = [NSNumber numberWithFloat:1.0];
//    scaleAnimation.toValue =[NSNumber numberWithFloat:3.0];
//    scaleAnimation.repeatCount = MAXFLOAT;
//    scaleAnimation.autoreverses = YES;
//    scaleAnimation.fillMode = kCAFillModeForwards;
//    scaleAnimation.removedOnCompletion = NO;
//    return scaleAnimation;
//    
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
